import static org.junit.Assert.*;
import org.junit.Test;
import testesbruno.Imovel;
import testesbruno.Contrato;
import testesbruno.GerenciadorContrato;

/**
 * CT07 - Cancelar Contrato com multa.
 *
 * Verifica:
 * - cálculo da multa
 * - mudança do estado do imóvel
 * - registro da multa
 *
 * @author Carlos Eduardo
 */
public class CasosTeste07 {

    @Test
    public void cancelarContratoComMulta() {

        Imovel imovel =
                new Imovel("001", "Alugado");

        Contrato contrato =
                new Contrato(
                        1,
                        imovel,
                        1000.00,
                        10
                );

        GerenciadorContrato gerenciador =
                new GerenciadorContrato();

        double multa =
                gerenciador.cancelarContrato(
                        contrato
                );

        assertEquals(
                4500.0,
                multa,
                0.01
        );

        assertEquals(
                "Disponivel",
                imovel.getEstado()
        );

        assertEquals(
                4500.0,
                gerenciador.getMultaRegistrada(),
                0.01
        );
    }
}