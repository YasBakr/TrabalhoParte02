import static org.junit.Assert.*;
import org.junit.Test;
import testesbruno.Imovel;
import testesbruno.Contrato;
import testesbruno.GerenciadorContrato;

public class CasosTeste06 {

    /**
 * CT06 - Criar Contrato com imóvel indisponível.
 *
 * Objetivo:
 * Verificar se o sistema impede a criação de contrato
 * quando o imóvel já se encontra alugado.
 */
@Test
public void criarContratoComImovelIndisponivel() {

    // Criação de um imóvel já alugado
    Imovel imovel = new Imovel("001", "Alugado");

    // Instancia o gerenciador responsável pelos contratos
    GerenciadorContrato gerenciador = new GerenciadorContrato();

    // Tenta criar um contrato para um imóvel indisponível
    Contrato contrato = gerenciador.criarContrato(imovel);

    // Verifica se nenhum contrato foi criado
    assertNull(contrato);

    // Verifica se a mensagem de erro correta foi exibida
    assertEquals(
        "Imovel nao disponivel",
        gerenciador.getMensagemErro()
    );
  }
}
