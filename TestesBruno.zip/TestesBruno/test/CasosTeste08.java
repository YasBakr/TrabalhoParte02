import static org.junit.Assert.*;
import org.junit.Test;
import testesbruno.SolicitacaoServico;
import testesbruno.GerenciadorServico;
/**
 * CT08 - Solicitar Serviço.
 *
 * Verifica se a solicitação é registrada
 * e retorna o status aprovado.
 *
 * @author Carlos Eduardo
 */
public class CasosTeste08 {

    @Test
    public void solicitarServico() {

        GerenciadorServico servico =
                new GerenciadorServico();

        SolicitacaoServico solicitacao =
                servico.solicitarServico(
                        1,
                        "Manutencao",
                        "Troca de torneira"
                );

        assertEquals(
                "Aprovado",
                solicitacao.getStatus()
        );
    }
}
