package testesbruno;

/**
 * Representa um contrato de locação.
 *
 * @author Carlos Eduardo
 */
public class Contrato {

    private int numero;
    private Imovel imovel;
    private double valorMensal;
    private int diasRestantes;

    /**
     * Construtor da classe Contrato.
     *
     * @param numero número do contrato
     * @param imovel imóvel associado
     * @param valorMensal valor mensal da locação
     * @param diasRestantes dias restantes até o término
     */
    public Contrato(int numero, Imovel imovel,
            double valorMensal, int diasRestantes) {

        this.numero = numero;
        this.imovel = imovel;
        this.valorMensal = valorMensal;
        this.diasRestantes = diasRestantes;
    }

    public int getNumero() {
        return numero;
    }

    public Imovel getImovel() {
        return imovel;
    }

    public double getValorMensal() {
        return valorMensal;
    }

    public int getDiasRestantes() {
        return diasRestantes;
    }
}
