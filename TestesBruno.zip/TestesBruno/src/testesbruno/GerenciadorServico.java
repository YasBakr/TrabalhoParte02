package testesbruno;

/**
 * Responsável pelas solicitações de serviço.
 *
 * @author Carlos Eduardo
 */
public class GerenciadorServico {

    /**
     * Registra uma solicitação de serviço.
     *
     * @param idContrato contrato relacionado
     * @param tipoServico tipo solicitado
     * @param descricao descrição do problema
     * @return solicitação aprovada
     */
    public SolicitacaoServico solicitarServico(
            int idContrato,
            String tipoServico,
            String descricao) {

        return new SolicitacaoServico(
                idContrato,
                tipoServico,
                descricao,
                "Aprovado"
        );
    }
}