package testesbruno;

public class GerenciadorContrato {
    private String mensagemErro;
    private double multaRegistrada;
    
    public Contrato criarContrato(Imovel imovel) {

    if (imovel.getEstado().equals("Alugado")) {
        exibirErro("Imovel nao disponivel");
        return null;
    }

    return new Contrato(
            1,
            imovel,
            1000.00,
            30
    );
}

    public void exibirErro(String mensagem) {
        this.mensagemErro = mensagem;
    }

    public String getMensagemErro() {
        return mensagemErro;
    }
    /**
 * Cancela um contrato e calcula a multa.
 *
 * Fórmula:
 * diasRestantes x 0.45 x valorMensal
 *
 * @param contrato contrato a cancelar
 * @return valor da multa
 */
public double cancelarContrato(Contrato contrato) {

    double multa =
            contrato.getDiasRestantes()
            * 0.45
            * contrato.getValorMensal();

    multaRegistrada = multa;

    contrato.getImovel()
            .setEstado("Disponivel");

    return multa;
    
}
public double getMultaRegistrada() {
    return multaRegistrada;
}
}
