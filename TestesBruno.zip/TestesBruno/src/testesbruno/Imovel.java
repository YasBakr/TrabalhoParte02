package testesbruno;

/**
 * Representa um imóvel do sistema imobiliário.
 * Cada imóvel possui um identificador único e um estado
 * que indica sua disponibilidade para contratos.
 *
 * @author Carlos Eduardo
 */
public class Imovel {

    /** Identificador único do imóvel */
    private String id;

    /** Estado atual do imóvel (Disponível, Alugado, Reservado, etc.) */
    private String estado;

    /**
     * Construtor da classe Imovel.
     *
     * @param id Identificador do imóvel
     * @param estado Estado inicial do imóvel
     */
    public Imovel(String id, String estado) {
        this.id = id;
        this.estado = estado;
    }

    /**
     * Retorna o identificador do imóvel.
     *
     * @return id do imóvel
     */
    public String getId() {
        return id;
    }

    /**
     * Retorna o estado atual do imóvel.
     *
     * @return estado do imóvel
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Altera o estado do imóvel.
     *
     * @param estado novo estado do imóvel
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
}