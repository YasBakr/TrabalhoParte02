package testesbruno;

/**
 * Representa uma solicitação de serviço.
 *
 * @author Carlos Eduardo
 */
public class SolicitacaoServico {

    private int idContrato;
    private String tipoServico;
    private String descricao;
    private String status;

    public SolicitacaoServico(
            int idContrato,
            String tipoServico,
            String descricao,
            String status) {

        this.idContrato = idContrato;
        this.tipoServico = tipoServico;
        this.descricao = descricao;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}