/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package criarcontrato;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Cliente
 */
public class CriarContratoTest {
    
    public CriarContratoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class CriarContrato.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CriarContrato.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of criarContrato method, of class CriarContrato.
     */
    @Test
    public void testCriarContrato() {
        System.out.println("criarContrato");
        int idInquilino = 0;
        Imovel imovel = null;
        double valor = 0.0;
        Contrato expResult = null;
        Contrato result = CriarContrato.criarContrato(idInquilino, imovel, valor);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
