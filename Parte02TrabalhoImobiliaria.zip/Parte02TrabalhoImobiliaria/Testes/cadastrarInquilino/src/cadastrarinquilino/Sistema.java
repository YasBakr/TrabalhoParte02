/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastrarinquilino;

/**
 *
 * @author Cliente
 */
class Sistema {

    public String cadastrarInquilino(
            String nome,
            String cpf,
            String email,
            String telefone) {

        // CPF válido (11 dígitos)
        if (cpf.length() == 11) {

            return confirmarCadastro(1);
        }

        return "Erro";
    }

    public String confirmarCadastro(int id) {

        return "Cadastro confirmado. ID: " + id;
    }
}