/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cadastrarinquilino;

/**
 * CT03 - Cadastro válido
 */
public class CadastrarInquilino {

    public static void main(String[] args) {

        Sistema sistema = new Sistema();

        String resposta =
                sistema.cadastrarInquilino(
                        "Vinicus",
                        "12345678901",
                        "vini@email.com",
                        "999999999"
                );

        System.out.println(resposta);
    }
}