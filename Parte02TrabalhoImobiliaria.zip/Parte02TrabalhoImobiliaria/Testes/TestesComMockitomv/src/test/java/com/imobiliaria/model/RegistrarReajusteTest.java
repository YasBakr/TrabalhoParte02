/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.imobiliaria.model;

/**
 *
 * @author bielz
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
 
import java.util.ArrayList;
import java.util.List;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
 
/**
 * CT15 - Registrar Reajuste de Contrato (SD_14).
 *
 * Verifica se o Sistema busca o contrato, calcula o novo valor através da
 * EstrategiaPreco (Strategy), atualiza o contrato, registra o histórico de
 * reajustes e notifica os observadores (padrão Observer), na ordem
 * correta.
 *
 * Utiliza MOCKS para BancoDeDados, EstrategiaPreco e Observer.
 */
public class RegistrarReajusteTest {
 
    private BancoDeDados bancoDeDadosMock;
    private EstrategiaPreco estrategiaPrecoMock;
    private Observer observerMock;
    private Sistema sistema;
 
    @BeforeEach
    void setUp() {
        bancoDeDadosMock = mock(BancoDeDados.class);
        estrategiaPrecoMock = mock(EstrategiaPreco.class);
        observerMock = mock(Observer.class);
 
        List<Observer> observadores = new ArrayList<>();
        observadores.add(observerMock);
 
        sistema = new Sistema(bancoDeDadosMock, estrategiaPrecoMock, mock(ServicoBoleto.class), observadores);
    }
 
    @Test
    void deveCalcularNovoValorAtualizarContratoERegistrarHistorico() {
        String idContrato = "C001";
        double indiceReajuste = 0.05;
 
        Contrato contratoFake = new Contrato(idContrato, "I001", 1500.0, "Alugado");
 
        when(bancoDeDadosMock.buscarContrato(idContrato)).thenReturn(contratoFake);
        when(estrategiaPrecoMock.calcularPreco(1500.0, indiceReajuste)).thenReturn(1575.0);
 
        double novoValor = sistema.registrarReajuste(idContrato, indiceReajuste);
 
        assertEquals(1575.0, novoValor);
 
        // Verifica a ordem correta das interações (conforme SD_14)
        InOrder ordem = inOrder(bancoDeDadosMock, estrategiaPrecoMock, observerMock);
        ordem.verify(bancoDeDadosMock).buscarContrato(idContrato);
        ordem.verify(estrategiaPrecoMock).calcularPreco(1500.0, indiceReajuste);
        ordem.verify(bancoDeDadosMock).atualizarContrato(idContrato, 1575.0);
        ordem.verify(bancoDeDadosMock).registrarHistoricoReajuste(idContrato, 1575.0);
        ordem.verify(observerMock).atualizar(idContrato);
 
        verify(bancoDeDadosMock, times(1)).atualizarContrato(idContrato, 1575.0);
        verify(observerMock, times(1)).atualizar(idContrato);
    }
}
