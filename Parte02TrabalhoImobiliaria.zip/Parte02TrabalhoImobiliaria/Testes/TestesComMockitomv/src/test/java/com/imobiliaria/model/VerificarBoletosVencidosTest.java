/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.imobiliaria.model;

/**
 *
 * @author bielz
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
 
import java.util.ArrayList;
import java.util.List;
 
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
 
/**
 * CT13 - Verificar Boletos Vencidos e Aplicar Multa (SD_8).
 *
 * Verifica se a rotina automática busca os boletos vencidos e, para cada
 * um deles, calcula a multa ({@code valor x 0.02 + jurosDia}), registra a
 * multa na persistência e notifica os observadores (padrão Observer).
 *
 * Utiliza MOCKS para BancoDeDados e Observer.
 */
public class VerificarBoletosVencidosTest {
 
    private BancoDeDados bancoDeDadosMock;
    private Observer observerMock;
    private SistemaAuto sistemaAuto;
 
    @BeforeEach
    void setUp() {
        bancoDeDadosMock = mock(BancoDeDados.class);
        observerMock = mock(Observer.class);
 
        List<Observer> observadores = new ArrayList<>();
        observadores.add(observerMock);
 
        sistemaAuto = new SistemaAuto(bancoDeDadosMock, observadores);
    }
 
    @Test
    void deveCalcularEregistrarMultaParaCadaBoletoVencido() {
        Boleto boleto1 = new Boleto("B001", 1000.0, "2026-05-10", "INQ01");
        Boleto boleto2 = new Boleto("B002", 800.0, "2026-05-12", "INQ02");
 
        List<Boleto> vencidos = new ArrayList<>();
        vencidos.add(boleto1);
        vencidos.add(boleto2);
 
        when(bancoDeDadosMock.verificarBoletosVencidos()).thenReturn(vencidos);
 
        sistemaAuto.verificarBoletosVencidos();
 
        double multaEsperada1 = (1000.0 * 0.02) + 2.50; // 22.50
        double multaEsperada2 = (800.0 * 0.02) + 2.50;  // 18.50
 
        verify(bancoDeDadosMock).registrarMulta("B001", multaEsperada1);
        verify(bancoDeDadosMock).registrarMulta("B002", multaEsperada2);
 
        // Cada boleto vencido deve notificar o observador uma vez
        verify(observerMock, times(2)).atualizar(anyString());
        verify(observerMock).atualizar("INQ01");
        verify(observerMock).atualizar("INQ02");
 
        verify(bancoDeDadosMock, times(1)).verificarBoletosVencidos();
    }
}