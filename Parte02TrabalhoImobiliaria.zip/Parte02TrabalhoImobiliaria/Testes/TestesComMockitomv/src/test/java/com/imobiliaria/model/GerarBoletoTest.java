/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.imobiliaria.model;

/**
 *
 * @author bielz
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
 
import java.util.ArrayList;
import java.util.List;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
 
/**
 * CT12 - Gerar Boleto (SD_7).
 *
 * Verifica se o Sistema busca o contrato e os serviços do mês,
 * calcula o valor total via EstrategiaPreco (Strategy), emite o boleto
 * via ServicoBoleto e persiste o resultado, na ordem correta.
 *
 * Utiliza MOCKS para BancoDeDados, EstrategiaPreco e ServicoBoleto.
 */
public class GerarBoletoTest {
 
    private BancoDeDados bancoDeDadosMock;
    private EstrategiaPreco estrategiaPrecoMock;
    private ServicoBoleto servicoBoletoMock;
    private Sistema sistema;
 
    @BeforeEach
    void setUp() {
        bancoDeDadosMock = mock(BancoDeDados.class);
        estrategiaPrecoMock = mock(EstrategiaPreco.class);
        servicoBoletoMock = mock(ServicoBoleto.class);
 
        List<Observer> observadores = new ArrayList<>();
 
        sistema = new Sistema(bancoDeDadosMock, estrategiaPrecoMock, servicoBoletoMock, observadores);
    }
 
    @Test
    void deveGerarBoletoComValorTotalCalculadoCorretamente() {
        String idContrato = "C001";
        String dataVencimento = "2026-07-10";
 
        Contrato contratoFake = new Contrato(idContrato, "I001", 1500.0, "Alugado");
 
        when(bancoDeDadosMock.buscarContrato(idContrato)).thenReturn(contratoFake);
        when(bancoDeDadosMock.buscarServicosDoMes(idContrato)).thenReturn(200.0);
        when(estrategiaPrecoMock.calcularPreco(1500.0, 200.0)).thenReturn(1700.0);
 
        Boleto boletoFake = new Boleto("B001", 1700.0, dataVencimento, "I001");
        when(servicoBoletoMock.emitirBoleto(idContrato, 1700.0, dataVencimento)).thenReturn(boletoFake);
 
        Boleto resultado = sistema.gerarBoleto(idContrato, dataVencimento);
 
        assertEquals(1700.0, resultado.getValorTotal());
        assertEquals("B001", resultado.getCodigoBoleto());
 
        // Verifica a ordem correta das interações (conforme SD_7)
        InOrder ordem = inOrder(bancoDeDadosMock, estrategiaPrecoMock, servicoBoletoMock);
        ordem.verify(bancoDeDadosMock).buscarContrato(idContrato);
        ordem.verify(bancoDeDadosMock).buscarServicosDoMes(idContrato);
        ordem.verify(estrategiaPrecoMock).calcularPreco(1500.0, 200.0);
        ordem.verify(servicoBoletoMock).emitirBoleto(idContrato, 1700.0, dataVencimento);
        ordem.verify(bancoDeDadosMock).salvarBoleto(boletoFake);
 
        verify(bancoDeDadosMock, times(1)).salvarBoleto(boletoFake);
    }
}
