/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.imobiliaria.model;

/**
 *
 * @author bielz
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
 
/**
 * CT14 - Registrar Vistoria com Anexos (SD_12).
 *
 * Verifica se o Sistema obtém a descrição da unidade do imóvel
 * (padrão Composite), salva a vistoria, salva os anexos (fotos) e
 * notifica os observadores (padrão Observer) sobre a atualização do
 * imóvel, na ordem correta.
 *
 * Utiliza MOCKS para BancoDeDados, Observer e ImovelUnidade.
 */
public class RegistrarVistoriaTest {
 
    private BancoDeDados bancoDeDadosMock;
    private Observer observerMock;
    private ImovelUnidade unidadeMock;
    private Sistema sistema;
 
    @BeforeEach
    void setUp() {
        bancoDeDadosMock = mock(BancoDeDados.class);
        observerMock = mock(Observer.class);
        unidadeMock = mock(ImovelUnidade.class);
 
        List<Observer> observadores = new ArrayList<>();
        observadores.add(observerMock);
 
        sistema = new Sistema(bancoDeDadosMock, mock(EstrategiaPreco.class),
                mock(ServicoBoleto.class), observadores);
    }
 
    @Test
    void deveRegistrarVistoriaSalvarAnexosENotificarObserver() {
        String idImovel = "I001";
        List<String> fotos = Arrays.asList("foto1.jpg", "foto2.jpg");
 
        when(unidadeMock.getDescricao()).thenReturn("Apartamento 2 quartos, 60m2");
        when(bancoDeDadosMock.salvarVistoria(any(Vistoria.class))).thenReturn("V001");
 
        String idVistoria = sistema.registrarVistoria(idImovel, "Entrada", "2026-06-15",
                "Vistoria de entrada do inquilino", fotos, unidadeMock);
 
        assertEquals("V001", idVistoria);
 
        // Verifica a ordem correta das interações (conforme SD_12)
        InOrder ordem = inOrder(unidadeMock, bancoDeDadosMock, observerMock);
        ordem.verify(unidadeMock).getDescricao();
        ordem.verify(bancoDeDadosMock).salvarVistoria(any(Vistoria.class));
        ordem.verify(bancoDeDadosMock).salvarAnexos(fotos, "V001");
        ordem.verify(observerMock).atualizar(idImovel);
 
        verify(bancoDeDadosMock, times(1)).salvarAnexos(fotos, "V001");
        verify(observerMock, times(1)).atualizar(idImovel);
    }
}
