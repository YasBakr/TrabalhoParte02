/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.imobiliaria.model;

/**
 *
 * @author bielz
 */
import java.util.List;
 
/**
 * Conjunto de interfaces e classes de apoio (DTOs e dependências externas)
 * utilizadas pelos protótipos {@link Sistema} e {@link SistemaAuto}.
 *
 * <p>Mantidas em um único arquivo por simplicidade do protótipo da
 * Parte 2 do projeto. Cada interface representa um colaborador externo
 * que, nos diagramas de sequência, aparece como uma classe/dependência
 * separada (ex.: persistência, estratégias de cálculo, observadores e
 * serviços externos). Nos testes unitários, essas interfaces são
 * substituídas por <i>stubs</i> ou <i>mocks</i>, permitindo testar a
 * lógica do {@link Sistema} de forma isolada.</p>
 */
 
/**
 * Abstrai o acesso ao armazenamento de dados (substitui o banco de dados
 * real, conforme a restrição do projeto que dispensa persistência real).
 *
 * <p>Cada método representa uma operação de leitura ou escrita que, nos
 * diagramas de sequência, é realizada sobre o objeto {@code BancoDeDados}.</p>
 */
interface BancoDeDados {
 
    /**
     * Busca um contrato pelo seu identificador.
     *
     * @param idContrato identificador único do contrato
     * @return o {@link Contrato} correspondente, ou {@code null} se não
     *         existir (em um protótipo real, poderia lançar uma exceção)
     */
    Contrato buscarContrato(String idContrato);
 
    /**
     * Calcula o valor total dos serviços extras solicitados no mês para um
     * determinado contrato (ex.: manutenções, reparos).
     *
     * @param idContrato identificador do contrato
     * @return soma dos valores dos serviços do mês
     */
    double buscarServicosDoMes(String idContrato);
 
    /**
     * Persiste um boleto recém-gerado.
     *
     * @param boleto o {@link Boleto} a ser salvo
     */
    void salvarBoleto(Boleto boleto);
 
    /**
     * Retorna a lista de boletos cuja data de vencimento já passou e que
     * ainda não foram pagos.
     *
     * @return lista de {@link Boleto} vencidos (pode ser vazia, nunca
     *         {@code null})
     */
    List<Boleto> verificarBoletosVencidos();
 
    /**
     * Registra o valor de multa aplicado a um boleto vencido.
     *
     * @param idBoleto   identificador (código) do boleto
     * @param valorMulta valor da multa calculada
     */
    void registrarMulta(String idBoleto, double valorMulta);
 
    /**
     * Persiste o registro de uma vistoria.
     *
     * @param vistoria objeto {@link Vistoria} contendo os dados coletados
     * @return identificador gerado para a vistoria (idVistoria)
     */
    String salvarVistoria(Vistoria vistoria);
 
    /**
     * Persiste os anexos (fotos) vinculados a uma vistoria já salva.
     *
     * @param fotos     lista de caminhos/URLs das fotos da vistoria
     * @param idVistoria identificador da vistoria à qual os anexos pertencem
     */
    void salvarAnexos(List<String> fotos, String idVistoria);
 
    /**
     * Atualiza o valor de aluguel vigente de um contrato (ex.: após um
     * reajuste).
     *
     * @param idContrato identificador do contrato
     * @param novoValor  novo valor de aluguel a ser persistido
     */
    void atualizarContrato(String idContrato, double novoValor);
 
    /**
     * Registra, no histórico do contrato, um evento de reajuste de valor.
     *
     * @param idContrato identificador do contrato
     * @param novoValor  valor resultante do reajuste, registrado no
     *                    histórico para auditoria futura
     */
    void registrarHistoricoReajuste(String idContrato, double novoValor);
}
 
/**
 * Define o contrato do padrão <b>Strategy</b> responsável pelo cálculo de
 * preços do sistema.
 *
 * <p>Implementações concretas podem representar diferentes políticas de
 * cálculo (ex.: preço fixo + serviços, reajuste por índice como IGPM/IPCA,
 * descontos promocionais, etc.), permitindo trocar o algoritmo de cálculo
 * sem alterar o código do {@link Sistema}.</p>
 */
interface EstrategiaPreco {
 
    /**
     * Calcula um valor monetário a partir de um valor base e de um
     * parâmetro adicional, cujo significado depende da estratégia
     * concreta utilizada.
     *
     * <p>Exemplos de uso no sistema:</p>
     * <ul>
     *   <li>Em {@link Sistema#gerarBoleto}, {@code valorBase} é o valor do
     *       aluguel e {@code parametro} é o total de serviços do mês,
     *       resultando no valor total do boleto;</li>
     *   <li>Em {@link Sistema#registrarReajuste}, {@code valorBase} é o
     *       valor atual do aluguel e {@code parametro} é o índice de
     *       reajuste, resultando no novo valor do contrato.</li>
     * </ul>
     *
     * @param valorBase valor monetário de referência
     * @param parametro parâmetro adicional usado no cálculo (depende da
     *                   estratégia concreta)
     * @return valor monetário resultante do cálculo
     */
    double calcularPreco(double valorBase, double parametro);
}
 
/**
 * Define o contrato do padrão <b>Observer</b>: representa um observador
 * que deseja ser notificado sempre que ocorrer uma mudança relevante em
 * uma entidade do sistema (ex.: imóvel, contrato, boleto).
 *
 * <p>No sistema, observadores concretos podem representar, por exemplo,
 * módulos de notificação por e-mail/SMS, atualização de relatórios ou
 * sincronização com outros módulos.</p>
 */
interface Observer {
 
    /**
     * Notifica o observador sobre uma atualização ocorrida.
     *
     * @param referencia identificador da entidade que sofreu a
     *                    atualização (ex.: idImovel, idContrato,
     *                    idInquilino), permitindo que o observador busque
     *                    os detalhes necessários
     */
    void atualizar(String referencia);
}
 
/**
 * Representa um serviço externo responsável pela emissão de boletos
 * bancários.
 *
 * <p>Em um cenário real, esta interface seria implementada por um
 * adaptador para uma API de cobrança (ex.: gateway de pagamentos).</p>
 */
interface ServicoBoleto {
 
    /**
     * Emite um novo boleto para um contrato.
     *
     * @param idContrato     identificador do contrato ao qual o boleto se
     *                        refere
     * @param valorTotal     valor total a ser cobrado no boleto
     * @param dataVencimento data de vencimento do boleto (formato livre,
     *                        ex.: {@code "yyyy-MM-dd"})
     * @return o {@link Boleto} gerado, contendo o código identificador
     *         retornado pelo serviço externo
     */
    Boleto emitirBoleto(String idContrato, double valorTotal, String dataVencimento);
}
 
/**
 * Define o contrato de uma unidade do imóvel no padrão <b>Composite</b>.
 *
 * <p>Pode representar tanto uma unidade individual (folha) quanto um
 * agrupamento de unidades (composição), de forma transparente para o
 * {@link Sistema}.</p>
 */
interface ImovelUnidade {
 
    /**
     * Retorna a descrição textual da unidade do imóvel (ex.: tipo,
     * metragem, número de cômodos), utilizada para compor o registro de
     * vistoria.
     *
     * @return descrição da unidade do imóvel
     */
    String getDescricao();
}
 
/**
 * Representa um contrato de locação entre um inquilino e um imóvel.
 *
 * <p>É um objeto de dados (DTO) simples, sem comportamento, utilizado
 * para transportar as informações relevantes do contrato entre o
 * {@link BancoDeDados} e o {@link Sistema}.</p>
 */
class Contrato {
 
    /** Identificador único do contrato. */
    private final String idContrato;
 
    /** Identificador do imóvel associado ao contrato. */
    private final String idImovel;
 
    /** Valor vigente do aluguel do contrato. */
    private final double valorAluguel;
 
    /** Situação atual do contrato (ex.: "Alugado", "Encerrado"). */
    private final String status;
 
    /**
     * Cria um novo registro de contrato.
     *
     * @param idContrato   identificador único do contrato
     * @param idImovel     identificador do imóvel relacionado
     * @param valorAluguel valor vigente do aluguel
     * @param status       situação atual do contrato
     */
    public Contrato(String idContrato, String idImovel, double valorAluguel, String status) {
        this.idContrato = idContrato;
        this.idImovel = idImovel;
        this.valorAluguel = valorAluguel;
        this.status = status;
    }
 
    /**
     * @return o identificador único do contrato
     */
    public String getIdContrato() { return idContrato; }
 
    /**
     * @return o identificador do imóvel associado ao contrato
     */
    public String getIdImovel() { return idImovel; }
 
    /**
     * @return o valor vigente do aluguel
     */
    public double getValorAluguel() { return valorAluguel; }
 
    /**
     * @return a situação atual do contrato
     */
    public String getStatus() { return status; }
}
 
/**
 * Representa um boleto de cobrança gerado pelo sistema.
 *
 * <p>É um objeto de dados (DTO) simples, sem comportamento, utilizado
 * para transportar as informações do boleto entre o {@link Sistema},
 * o {@link ServicoBoleto} e o {@link BancoDeDados}.</p>
 */
class Boleto {
 
    /** Código identificador do boleto, normalmente retornado pelo serviço de emissão. */
    private final String codigoBoleto;
 
    /** Valor total a ser pago (aluguel + serviços do mês, quando aplicável). */
    private final double valorTotal;
 
    /** Data de vencimento do boleto. */
    private final String dataVencimento;
 
    /** Identificador do inquilino responsável pelo pagamento do boleto. */
    private final String idInquilino;
 
    /**
     * Cria um novo registro de boleto.
     *
     * @param codigoBoleto   código identificador do boleto
     * @param valorTotal     valor total do boleto
     * @param dataVencimento data de vencimento do boleto
     * @param idInquilino    identificador do inquilino responsável pelo pagamento
     */
    public Boleto(String codigoBoleto, double valorTotal, String dataVencimento, String idInquilino) {
        this.codigoBoleto = codigoBoleto;
        this.valorTotal = valorTotal;
        this.dataVencimento = dataVencimento;
        this.idInquilino = idInquilino;
    }
 
    /**
     * @return o código identificador do boleto
     */
    public String getCodigoBoleto() { return codigoBoleto; }
 
    /**
     * @return o valor total do boleto
     */
    public double getValorTotal() { return valorTotal; }
 
    /**
     * @return a data de vencimento do boleto
     */
    public String getDataVencimento() { return dataVencimento; }
 
    /**
     * @return o identificador do inquilino responsável pelo pagamento
     */
    public String getIdInquilino() { return idInquilino; }
}
 
/**
 * Representa o registro de uma vistoria realizada em um imóvel (ex.:
 * vistoria de entrada ou saída de um inquilino).
 *
 * <p>É um objeto de dados (DTO) simples, sem comportamento, criado pelo
 * {@link Sistema#registrarVistoria} e persistido através do
 * {@link BancoDeDados}.</p>
 */
class Vistoria {
 
    /** Identificador do imóvel vistoriado. */
    private final String idImovel;
 
    /** Tipo da vistoria (ex.: "Entrada", "Saída", "Periódica"). */
    private final String tipo;
 
    /** Data em que a vistoria foi realizada. */
    private final String data;
 
    /** Descrição geral fornecida pelo corretor sobre a vistoria. */
    private final String descricao;
 
    /**
     * Descrição da unidade do imóvel no momento da vistoria, obtida via
     * padrão Composite ({@link ImovelUnidade#getDescricao()}).
     */
    private final String dadosUnidade;
 
    /**
     * Cria um novo registro de vistoria.
     *
     * @param idImovel     identificador do imóvel vistoriado
     * @param tipo         tipo da vistoria
     * @param data         data da vistoria
     * @param descricao    descrição geral da vistoria
     * @param dadosUnidade descrição da unidade do imóvel no momento da vistoria
     */
    public Vistoria(String idImovel, String tipo, String data, String descricao, String dadosUnidade) {
        this.idImovel = idImovel;
        this.tipo = tipo;
        this.data = data;
        this.descricao = descricao;
        this.dadosUnidade = dadosUnidade;
    }
 
    /**
     * @return o identificador do imóvel vistoriado
     */
    public String getIdImovel() { return idImovel; }
 
    /**
     * @return o tipo da vistoria
     */
    public String getTipo() { return tipo; }
 
    /**
     * @return a data em que a vistoria foi realizada
     */
    public String getData() { return data; }
 
    /**
     * @return a descrição geral fornecida pelo corretor
     */
    public String getDescricao() { return descricao; }
 
    /**
     * @return a descrição da unidade do imóvel no momento da vistoria
     */
    public String getDadosUnidade() { return dadosUnidade; }
}
