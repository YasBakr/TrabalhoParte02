/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.imobiliaria.model;

/**
 *
 * @author bielz
 */
import java.util.List;
 
/**
 * Protótipo da rotina diária automática do sistema (executor sem
 * interação direta de um ator humano).
 *
 * <p>Implementa o fluxo do diagrama de sequência <b>SD_8</b> -
 * Verificação de Boletos Vencidos, que percorre os boletos em atraso,
 * calcula e registra a multa correspondente e notifica os observadores
 * cadastrados (padrão <b>Observer</b>) para cada boleto vencido.</p>
 *
 * <p><b>Observação:</b> esta rotina é representada nos diagramas como
 * sendo disparada por uma "Rotina diária automática" (sem ator humano),
 * por isso foi modelada como uma classe independente de {@link Sistema},
 * embora compartilhe a mesma abstração de persistência
 * ({@link BancoDeDados}) e o mesmo mecanismo de notificação
 * ({@link Observer}).</p>
 */
public class SistemaAuto {
 
    /**
     * Percentual de multa aplicado sobre o valor total do boleto vencido
     * (2%), conforme especificado no diagrama SD_8.
     */
    private static final double PERCENTUAL_MULTA = 0.02;
 
    /**
     * Valor fixo de juros por dia de atraso, somado ao percentual de
     * multa no cálculo do valor final da multa.
     */
    private static final double JUROS_DIA = 2.50;
 
    /**
     * Abstração de persistência (substitui o banco de dados real).
     * Utilizada para buscar boletos vencidos e registrar as multas
     * calculadas.
     */
    private final BancoDeDados bancoDeDados;
 
    /**
     * Lista de observadores cadastrados (padrão <b>Observer</b>).
     * Cada observador é notificado para cada boleto vencido processado,
     * recebendo o identificador do inquilino correspondente.
     */
    private final List<Observer> observadores;
 
    /**
     * Cria uma instância da rotina automática com suas dependências
     * injetadas.
     *
     * @param bancoDeDados abstração de persistência (pode ser um stub ou
     *                      mock nos testes)
     * @param observadores lista de observadores que serão notificados
     *                      para cada boleto vencido processado (padrão
     *                      Observer); pode ser uma lista vazia se não
     *                      houver observadores cadastrados
     */
    public SistemaAuto(BancoDeDados bancoDeDados, List<Observer> observadores) {
        this.bancoDeDados = bancoDeDados;
        this.observadores = observadores;
    }
 
    /**
     * Verifica todos os boletos vencidos e aplica as respectivas multas
     * (SD_8).
     *
     * <p>Fluxo executado:</p>
     * <ol>
     *   <li>Busca, no {@link BancoDeDados}, a lista de boletos cuja data
     *       de vencimento já passou e que ainda não foram pagos;</li>
     *   <li>Para <b>cada</b> boleto vencido (laço {@code for}, equivalente
     *       ao bloco {@code loop} do diagrama SD_8):
     *     <ol type="a">
     *       <li>calcula o valor da multa pela fórmula
     *           {@code valorTotal x 0.02 + jurosDia};</li>
     *       <li>registra a multa calculada no {@link BancoDeDados},
     *           associada ao código do boleto;</li>
     *       <li>notifica todos os {@link Observer} cadastrados,
     *           repassando o identificador do inquilino responsável pelo
     *           boleto.</li>
     *     </ol>
     *   </li>
     * </ol>
     *
     * @implNote os valores {@link #PERCENTUAL_MULTA} (2%) e
     * {@link #JUROS_DIA} (R$ 2,50/dia) estão fixos como constantes da
     * classe. Em uma evolução futura, poderiam ser extraídos para uma
     * estratégia de cálculo de multa configurável.
     *
     * @implSpec se a lista de boletos vencidos retornada pelo
     * {@link BancoDeDados} estiver vazia, nenhuma multa é calculada e
     * nenhum observador é notificado.
     */
    public void verificarBoletosVencidos() {
        List<Boleto> vencidos = bancoDeDados.verificarBoletosVencidos();
 
        for (Boleto boleto : vencidos) {
            double valorMulta = (boleto.getValorTotal() * PERCENTUAL_MULTA) + JUROS_DIA;
 
            bancoDeDados.registrarMulta(boleto.getCodigoBoleto(), valorMulta);
 
            for (Observer observer : observadores) {
                observer.atualizar(boleto.getIdInquilino());
            }
        }
    }
}
