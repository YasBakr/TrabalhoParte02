/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.imobiliaria.model;

/**
 *
 * @author bielz
 */
import java.util.List;
 
/**
 * Protótipo do Sistema principal de gestão imobiliária.
 *
 * <p>Esta classe concentra os fluxos de negócio referentes aos seguintes
 * diagramas de sequência da Parte 2 do projeto:</p>
 * <ul>
 *   <li><b>SD_7</b> - Gerar Boleto: aplica o padrão <b>Strategy</b>
 *       ({@link EstrategiaPreco}) para calcular o valor total cobrado;</li>
 *   <li><b>SD_12</b> - Registrar Vistoria: utiliza o padrão
 *       <b>Composite</b> ({@link ImovelUnidade}) para obter os dados da
 *       unidade vistoriada e o padrão <b>Observer</b> para notificar
 *       interessados na atualização do imóvel;</li>
 *   <li><b>SD_14</b> - Registrar Reajuste de Contrato: combina o padrão
 *       <b>Strategy</b> ({@link EstrategiaPreco}) para calcular o novo
 *       valor do aluguel e o padrão <b>Observer</b> para notificar a
 *       atualização do contrato.</li>
 * </ul>
 *
 * <p><b>Observação:</b> conforme as restrições do projeto, esta classe não
 * realiza persistência real nem possui interface gráfica. Todas as
 * dependências externas (persistência, estratégias de cálculo, serviço de
 * boletos e observadores) são recebidas via injeção de dependência no
 * construtor, o que permite substituí-las por <i>stubs</i> ou
 * <i>mocks</i> nos testes unitários (JUnit/Mockito).</p>
 */
public class Sistema {
 
    /**
     * Abstração de persistência (substitui o banco de dados real).
     * Utilizada para buscar/salvar contratos, boletos e vistorias.
     */
    private final BancoDeDados bancoDeDados;
 
    /**
     * Estratégia de cálculo de preço (padrão <b>Strategy</b>).
     * Define como o valor final de boletos e reajustes é calculado.
     */
    private final EstrategiaPreco estrategiaPreco;
 
    /**
     * Serviço externo responsável pela emissão de boletos bancários.
     */
    private final ServicoBoleto servicoBoleto;
 
    /**
     * Lista de observadores cadastrados (padrão <b>Observer</b>).
     * Cada observador é notificado quando uma vistoria é registrada ou
     * quando um contrato é reajustado.
     */
    private final List<Observer> observadores;
 
    /**
     * Cria uma instância do Sistema com suas dependências injetadas.
     *
     * @param bancoDeDados    abstração de persistência (pode ser um stub
     *                        ou mock nos testes)
     * @param estrategiaPreco estratégia de cálculo de preço a ser
     *                        utilizada (padrão Strategy)
     * @param servicoBoleto   serviço externo de emissão de boletos
     * @param observadores    lista de observadores que serão notificados
     *                        sobre atualizações (padrão Observer); pode
     *                        ser uma lista vazia se não houver
     *                        observadores cadastrados
     */
    public Sistema(BancoDeDados bancoDeDados, EstrategiaPreco estrategiaPreco,
                    ServicoBoleto servicoBoleto, List<Observer> observadores) {
        this.bancoDeDados = bancoDeDados;
        this.estrategiaPreco = estrategiaPreco;
        this.servicoBoleto = servicoBoleto;
        this.observadores = observadores;
    }
 
    /**
     * Gera o boleto mensal de um contrato (SD_7).
     *
     * <p>Fluxo executado:</p>
     * <ol>
     *   <li>Busca o {@link Contrato} pelo identificador informado;</li>
     *   <li>Busca o total de serviços extras solicitados no mês para o
     *       contrato;</li>
     *   <li>Calcula o valor total a ser cobrado através da
     *       {@link EstrategiaPreco} (padrão Strategy), combinando o valor
     *       do aluguel com o total de serviços;</li>
     *   <li>Solicita ao {@link ServicoBoleto} a emissão do boleto com o
     *       valor total calculado;</li>
     *   <li>Persiste o boleto gerado através do {@link BancoDeDados}.</li>
     * </ol>
     *
     * @param idContrato     identificador do contrato para o qual o
     *                        boleto será gerado
     * @param dataVencimento data de vencimento do boleto (ex.:
     *                        {@code "2026-07-10"})
     * @return o {@link Boleto} gerado e já persistido
     *
     * @implNote o cálculo do valor total é totalmente delegado à
     * {@link EstrategiaPreco}, permitindo trocar a política de cobrança
     * (ex.: incluir descontos, taxas de serviço, etc.) sem alterar este
     * método.
     */
    public Boleto gerarBoleto(String idContrato, String dataVencimento) {
        Contrato contrato = bancoDeDados.buscarContrato(idContrato);
        double totalServicos = bancoDeDados.buscarServicosDoMes(idContrato);
 
        double valorTotal = estrategiaPreco.calcularPreco(contrato.getValorAluguel(), totalServicos);
 
        Boleto boleto = servicoBoleto.emitirBoleto(idContrato, valorTotal, dataVencimento);
        bancoDeDados.salvarBoleto(boleto);
 
        return boleto;
    }
 
    /**
     * Registra a vistoria de uma unidade do imóvel (SD_12).
     *
     * <p>Fluxo executado:</p>
     * <ol>
     *   <li>Obtém a descrição da unidade vistoriada através da
     *       {@link ImovelUnidade} (padrão Composite), que pode representar
     *       tanto uma unidade individual quanto um agrupamento de
     *       unidades de forma transparente;</li>
     *   <li>Monta um objeto {@link Vistoria} com os dados informados e a
     *       descrição da unidade;</li>
     *   <li>Persiste a vistoria através do {@link BancoDeDados}, obtendo o
     *       identificador gerado (idVistoria);</li>
     *   <li>Persiste os anexos (fotos) vinculados à vistoria;</li>
     *   <li>Notifica todos os {@link Observer} cadastrados (padrão
     *       Observer) sobre a atualização do imóvel, repassando o
     *       identificador do imóvel vistoriado.</li>
     * </ol>
     *
     * @param idImovel  identificador do imóvel vistoriado
     * @param tipo      tipo da vistoria (ex.: "Entrada", "Saída")
     * @param data      data em que a vistoria foi realizada
     * @param descricao descrição geral da vistoria, fornecida pelo
     *                   corretor
     * @param fotos     lista de caminhos/URLs das fotos anexadas à
     *                   vistoria
     * @param unidade   referência à unidade do imóvel (padrão Composite),
     *                   usada para obter a descrição da unidade
     * @return o identificador (idVistoria) gerado pela persistência
     *
     * @implNote a notificação dos observadores ocorre <i>após</i> a
     * persistência dos anexos, garantindo que, ao serem notificados, os
     * dados da vistoria já estejam totalmente salvos.
     */
    public String registrarVistoria(String idImovel, String tipo, String data,
                                     String descricao, List<String> fotos,
                                     ImovelUnidade unidade) {
 
        String dadosUnidade = unidade.getDescricao();
 
        Vistoria vistoria = new Vistoria(idImovel, tipo, data, descricao, dadosUnidade);
        String idVistoria = bancoDeDados.salvarVistoria(vistoria);
 
        bancoDeDados.salvarAnexos(fotos, idVistoria);
 
        for (Observer observer : observadores) {
            observer.atualizar(idImovel);
        }
 
        return idVistoria;
    }
 
    /**
     * Registra o reajuste de valor de um contrato (SD_14).
     *
     * <p>Fluxo executado:</p>
     * <ol>
     *   <li>Busca o {@link Contrato} pelo identificador informado;</li>
     *   <li>Calcula o novo valor do aluguel através da
     *       {@link EstrategiaPreco} (padrão Strategy), aplicando o índice
     *       de reajuste sobre o valor atual;</li>
     *   <li>Atualiza o valor vigente do contrato no
     *       {@link BancoDeDados};</li>
     *   <li>Registra o evento no histórico de reajustes do contrato, para
     *       fins de auditoria;</li>
     *   <li>Notifica todos os {@link Observer} cadastrados (padrão
     *       Observer) sobre a atualização do contrato.</li>
     * </ol>
     *
     * @param idContrato identificador do contrato a ser reajustado
     * @param indice     índice de reajuste a ser aplicado (o significado
     *                    exato depende da {@link EstrategiaPreco}
     *                    utilizada, ex.: percentual de IGPM/IPCA)
     * @return o novo valor do aluguel após o reajuste
     *
     * @implNote tanto a atualização do contrato quanto o registro no
     * histórico utilizam o mesmo {@code novoValor} calculado, garantindo
     * consistência entre o valor vigente e o histórico de alterações.
     */
    public double registrarReajuste(String idContrato, double indice) {
        Contrato contrato = bancoDeDados.buscarContrato(idContrato);
 
        double novoValor = estrategiaPreco.calcularPreco(contrato.getValorAluguel(), indice);
 
        bancoDeDados.atualizarContrato(idContrato, novoValor);
        bancoDeDados.registrarHistoricoReajuste(idContrato, novoValor);
 
        for (Observer observer : observadores) {
            observer.atualizar(idContrato);
        }
 
        return novoValor;
    }
}
