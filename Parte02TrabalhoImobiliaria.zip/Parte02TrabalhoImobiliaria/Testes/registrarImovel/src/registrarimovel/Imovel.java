/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registrarimovel;

/**
 *
 * @author Cliente
 */
class Imovel {

    private final int id;
    private final String tipo;
    private final double valor;
    private final String endereco;
    private final String estado;

    // Construtor
    public Imovel(int id, String tipo,
                  double valor, String endereco) {

        this.id = id;
        this.tipo = tipo;
        this.valor = valor;
        this.endereco = endereco;

        // Todo imóvel inicia disponível
        this.estado = "Disponivel";
    }

    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public String getEstado() {
        return estado;
    }
}
