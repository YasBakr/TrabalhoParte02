/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registrarimovel;

 /**
 * CT01 - Registrar Imóvel
 * Cria um imóvel do tipo Casa com estado Disponível e retorna um ID válido.
 */
public class RegistrarImovel {

    public static void main(String[] args) {

        // Criando o imóvel
        Imovel imovel = new Imovel(
                1,
                "Casa",
                1500.00,
                "Rua Para, 154"
        );

        // Exibindo os dados para validação
        System.out.println("ID: " + imovel.getId());
        System.out.println("Tipo: " + imovel.getTipo());
        System.out.println("Estado: " + imovel.getEstado());
    }
}